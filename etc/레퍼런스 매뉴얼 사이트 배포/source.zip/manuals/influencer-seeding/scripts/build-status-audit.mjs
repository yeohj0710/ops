#!/usr/bin/env node
/* 「인플루언서」 탭의 진행 상태가 협상 메모·진행 증거와 맞는지 점검한다.
 *
 *   node build-status-audit.mjs --out <작업폴더>/status-audit.json
 *   node build-status-audit.mjs --self-test
 *
 * 값을 쓰지 않는다. 명시적인 근거만 자동 변경 후보로 만들고, 수락·취소처럼
 * 원문이나 확정 체크를 다시 봐야 하는 것은 검토 목록으로 분리한다.
 */

import assert from "node:assert/strict";
import fs from "node:fs";
import { readRows } from "./build-sort-plan.mjs";

const SHEET_ID = "1heUo8C09kEHMQo7qOTYC5bMOCSMTHCvb-m7O3tm2BOE";
const TAB = "인플루언서";

const txt = (value) => String(value ?? "").trim();
const isTrue = (value) => value === true || value === 1 || txt(value).toUpperCase() === "TRUE";
const has = (text, patterns) => patterns.some((pattern) => pattern.test(text));

const CANCELLATION = [
  /(?:이번\s*캠페인|배정|협업|진행).{0,20}(?:취소|철회|빠짐|불참)/i,
  /\b(?:cancel(?:led)?|withdraw(?:n)?)\b/i,
];
const REJECTION = [
  /(?:명시적\s*)?거절/i,
  /(?:광고|협업|캠페인|참여|진행).{0,20}(?:안\s*함|안\s*받|않겠|하지\s*않|불가)/i,
  /(?:관심|의향).{0,10}(?:없음|없다)/i,
  /협상\s*불가/i,
  /조건.{0,15}(?:맞지\s*않|안\s*맞)/i,
  /\bnot\s+interested\b/i,
  /\bdeclin(?:e|ed)\b/i,
  /(?:拒绝|不参加|不合作)/,
];
const REJECT_FIT = [
  /(?:콘텐츠|언어권|캠페인|약국\s*이미지|타깃).{0,20}(?:부적합|맞지\s*않|안\s*맞)/i,
  /(?:이미지|콘텐츠).{0,30}약국.{0,20}(?:맞지\s*않|안\s*맞)/i,
  /(?:부적합|내부\s*제외)/i,
];
const SCHEDULE_HOLD = [
  /(?:\d{1,2}\s*월|다음\s*달|귀국\s*후|입국\s*후).{0,25}(?:부터\s*)?(?:가능|희망)/i,
  /(?:\d{1,2}\s*월|다음\s*달|연말).{0,25}(?:한국|방한|귀국|방문|촬영).{0,25}(?:오|온다고|계획|가능|연락)/i,
  /그때.{0,12}연락하기로/i,
  /(?:현재|지금).{0,15}(?:방문|촬영)\s*일정.{0,10}없.{0,40}(?:향후|나중).{0,20}(?:협력|협업)\s*희망/i,
  /(?:일정|스케줄|방문|촬영).{0,20}(?:미룸|미뤄|연기|보류)/i,
  /일정.{0,15}(?:차\s*있|가득)/i,
  /(?:현재|지금|그때).{0,10}한국에.{0,12}(?:없|계시지\s*않)/i,
  /(?:한국|서울).{0,12}(?:오|올|방문|입국).{0,20}(?:계획|연락|예정|가능)/i,
  /(?:오시면|오면|올\s*계획).{0,20}연락/i,
  /\d{1,2}\s*\/\s*\d{1,2}.{0,12}(?:한국|서울).{0,12}(?:오|방문|입국)/i,
];
const STRONG_SCHEDULE_HOLD = [
  /(?:일정|스케줄|방문|촬영).{0,20}(?:미룸|미뤄|연기|보류)/i,
  /(?:현재|지금).{0,10}한국에.{0,12}(?:없|계시지\s*않)/i,
  /그때.{0,12}연락하기로/i,
  /(?:10|11|12)\s*월.{0,25}(?:한국|방한|귀국|방문|촬영).{0,25}(?:오|온다고|계획|가능)/i,
  /연말.{0,25}(?:한국|방한|귀국|방문|촬영)/i,
];
const FUTURE_WILLING = [
  /(?:향후|나중|추후).{0,20}(?:협력|협업|진행).{0,12}(?:희망|가능|의향)/i,
  /(?:협력|협업|진행).{0,20}(?:향후|나중|추후).{0,12}(?:희망|가능|의향)/i,
];
const NEGOTIATION = [
  /(?:가격|비용|금액|단가|예산|페이팔|fee|budget).{0,25}(?:요구|희망|제시|문의|얼마|협의|협상|조율)/i,
  /(?:요구|희망|제시|문의|얼마|협의|협상|조율).{0,25}(?:가격|비용|금액|단가|예산|원|fee|budget)/i,
  /(?:₩|￦|\bKRW\b|\d[\d,.]*\s*원).{0,15}(?:요구|희망|제시|문의|협의|협상|조율)/i,
  /(?:세금계산서|지급일|payment).{0,20}(?:질문|문의|협의|조율)/i,
  /조건.{0,20}(?:협의\s*중|조율\s*중|문의)/i,
  /\d[\d,.]*\s*(?:만\s*)?원.{0,15}(?:가능|어떠|괜찮|될까)/i,
  /(?:원하|희망).{0,12}제품.{0,12}(?:따로|별도|다름|있음)/i,
];
const HOLD = [
  /DM\s*불가/i,
  /(?:연락\s*(?:수단|방법)|컨택).{0,12}(?:없|불가)/i,
  /(?:방문\s*(?:계획|일정)).{0,12}(?:없|미정)/i,
];
const ACCEPTANCE = [
  /(?:수락|동의)/i,
  /(?:협업|캠페인|참여|진행).{0,20}(?:하겠|가능|확정)/i,
  /합의.{0,10}(?:완료|확정)/i,
  /\b(?:accept(?:ed)?|agreed)\b/i,
  /(?:同意合作|接受合作|参加できます)/,
];
const NO_REPLY = [/(?:답장|회신|응답).{0,10}(?:없|대기)/i];
const NO_PROOF = [
  /(?:합의|수락).{0,20}(?:원문.{0,10}없|확인되지\s*않|확인\s*안\s*됨)/i,
  /(?:원문|증거).{0,15}(?:없|미확인)/i,
];
const INACTIVE_VISIT = [
  /미미라인\s*아님/i,
  /현재\s*캠페인\s*아님/i,
];
const UNSET_VISIT = [
  /^(?:아직\s*)?미정\.?$/i,
  /일정\s*미정/i,
];

const isUnassigned = (row) => {
  const value = txt(row["배정 건"]);
  return !value || value === "미배정";
};

function candidate(row, recommendedStatus, reason, evidenceColumn = "③협상 관련 메모", mode = "auto") {
  const currentStatus = txt(row["진행 상태"]);
  if (currentStatus === recommendedStatus && mode === "auto") return null;
  return {
    mode,
    row: row.row,
    key: row.key,
    currentStatus,
    recommendedStatus,
    reason,
    evidenceColumn,
    evidence: txt(row[evidenceColumn]),
  };
}

export function classifyRow(row) {
  const currentStatus = txt(row["진행 상태"]);
  const memo = txt(row["③협상 관련 메모"]);
  const visit = txt(row["⑥방문 예정일"]);
  const confirmed = isTrue(row["⑤확정"]);

  if (currentStatus === "확정" && confirmed && has(memo, CANCELLATION)) {
    return candidate(row, "확인 필요", "확정 체크와 취소·철회 메모가 충돌함", "③협상 관련 메모", "review");
  }

  // ⑤확정은 과거 합의 기록이다. 현재 캠페인 배정·일정·협상 상태보다 우선하지 않는다.
  if (has(visit, INACTIVE_VISIT)) {
    return candidate(row, "보류", "방문 예정일에 현재 캠페인 대상이 아님을 명시함", "⑥방문 예정일");
  }
  if (currentStatus === "확정" && !isUnassigned(row) && has(visit, UNSET_VISIT)) {
    return candidate(row, "일정 보류", "활성 배정은 있으나 방문 일정이 미정임", "⑥방문 예정일");
  }
  if (currentStatus === "확정" && !isUnassigned(row)) return null;
  if (currentStatus === "확정" && isUnassigned(row)) {
    if (has(memo, REJECTION)) return candidate(row, "거절", "명시적 거절 또는 참여 불가 메모");
    if (has(memo, REJECT_FIT)) return candidate(row, "반려", "콘텐츠·언어권·캠페인 적합도 부족 메모");
    if (has(memo, NO_REPLY) && isTrue(row["①DM 발송"]) && !isTrue(row["②응답"])) {
      return candidate(row, "1차 발송", "1차 제안 발송 뒤 응답이 없다는 메모와 단계 체크를 따름");
    }
    if (has(memo, NEGOTIATION)) return candidate(row, "협상중", "현재 배정이 없고 금액·조건이 미합의 상태임");
    if (has(memo, SCHEDULE_HOLD) || has(visit, UNSET_VISIT)) {
      return candidate(row, "일정 보류", "현재 배정이 없고 방문·촬영 시기만 남아 있음");
    }
    // 미배정만으로 보류하지 않는다. 명시적 반대 근거가 없으면 기존 확정 근거를 보존한다.
    return null;
  }

  if (!memo) {
    if (currentStatus === "확정") {
      return candidate(row, "확인 필요", "확정 상태인데 ⑤확정과 협상 메모 근거가 없음", "진행 상태", "review");
    }
    return null;
  }

  if (currentStatus === "거절" || currentStatus === "반려") return null;

  if (currentStatus === "확정" && has(memo, CANCELLATION)) {
    return candidate(row, "확인 필요", "확정 상태와 취소·철회 메모가 충돌함", "③협상 관련 메모", "review");
  }
  if (has(memo, REJECT_FIT)) return candidate(row, "반려", "콘텐츠·언어권·캠페인 적합도 부족 메모");
  if (has(memo, NO_REPLY) || has(memo, NO_PROOF)) return null;
  if (currentStatus === "일정 보류" && has(memo, SCHEDULE_HOLD)) return null;
  if (has(memo, FUTURE_WILLING)) return candidate(row, "일정 보류", "현재 일정은 어렵지만 향후 협업 의사가 있음");
  if (has(memo, REJECTION)) return candidate(row, "거절", "명시적 거절 또는 참여 불가 메모");
  if (has(memo, NEGOTIATION)) return candidate(row, "협상중", "금액·조건 협상 메모");
  if (currentStatus === "협상중" && has(memo, SCHEDULE_HOLD) && !has(memo, STRONG_SCHEDULE_HOLD)) return null;
  if (has(memo, SCHEDULE_HOLD)) return candidate(row, "일정 보류", "참여 의사는 있으나 일정이 미뤄진 메모");
  if (has(memo, HOLD)) return candidate(row, "보류", "연락 통로나 방문 계획이 없는 메모");
  if (has(memo, ACCEPTANCE)) {
    return candidate(row, "확정", "수락으로 보이는 메모는 원문과 ⑤확정을 확인해야 함", "③협상 관련 메모", "review");
  }
  return null;
}

export async function buildStatusAudit(opts = {}) {
  const sheet = await readRows({ sheetId: opts.sheetId ?? SHEET_ID, tab: opts.tab ?? TAB, gid: opts.gid });
  const candidates = sheet.rows.map(classifyRow).filter(Boolean);
  const auto = candidates.filter((item) => item.mode === "auto");
  const review = candidates.filter((item) => item.mode === "review");
  return {
    시트: opts.sheetId ?? SHEET_ID,
    탭: opts.tab ?? TAB,
    gid: sheet.gid,
    행: sheet.rows.length,
    자동변경후보: auto,
    검토후보: review,
    요약: {
      자동변경: auto.length,
      검토필요: review.length,
      상태별: Object.fromEntries([...new Set(auto.map((item) => item.recommendedStatus))].map((status) => [status, auto.filter((item) => item.recommendedStatus === status).length])),
    },
  };
}

function selfTest() {
  const row = (status, memo, extra = {}) => ({ row: 3, key: "@test", "진행 상태": status, "③협상 관련 메모": memo, "⑤확정": "FALSE", "배정 건": "미배정", ...extra });
  assert.equal(classifyRow(row("협상중", "", { "⑤확정": "TRUE" })), null);
  assert.equal(classifyRow(row("협상중", "11월부터 촬영 가능하다고 하심")).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("1차 발송", "이번 캠페인은 진행하지 않겠습니다")).recommendedStatus, "거절");
  assert.equal(classifyRow(row("일정 보류", "현재 서울 방문 일정이 없어 거절했지만 향후 협업 희망")), null);
  assert.equal(classifyRow(row("미접촉", "콘텐츠가 캠페인에 맞지 않음")).recommendedStatus, "반려");
  assert.equal(classifyRow(row("미접촉", "DM불가")).recommendedStatus, "보류");
  assert.equal(classifyRow(row("1차 발송", "150,000원 희망")).recommendedStatus, "협상중");
  assert.equal(classifyRow(row("협상중", "협업 진행하겠습니다")).mode, "review");
  assert.equal(classifyRow(row("확정", "", { "⑤확정": "TRUE" })), null);
  assert.equal(classifyRow(row("확정", "", { "⑤확정": "TRUE", "⑥방문 예정일": "미미라인 아님." })).recommendedStatus, "보류");
  assert.equal(classifyRow(row("확정", "11월부터 촬영 가능", { "⑤확정": "TRUE" })).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("확정", "가격 협의 중", { "⑤확정": "TRUE" })).recommendedStatus, "협상중");
  assert.equal(classifyRow(row("확정", "서울으로 올 계획이 있으면 연락하기로 했음.", { "⑤확정": "TRUE" })).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("확정", "tiktok은 따로 비용 발생. (9/4한국으로 오심.)", { "⑤확정": "TRUE" })).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("확정", "한국으로 오시면 저희한테 연락주신다고 하심.", { "⑤확정": "TRUE" })).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("확정", "20만 원 가능할까요?", { "⑤확정": "TRUE" })).recommendedStatus, "협상중");
  assert.equal(classifyRow(row("일정 보류", "10만원 제안 수락. 10월에 한국 방문 가능.")), null);
  assert.equal(classifyRow(row("확정", "협업한 생각이 있지만, 원하시는 제품이 따로 있음.", { "⑤확정": "TRUE" })).recommendedStatus, "협상중");
  assert.equal(classifyRow(row("확정", "1차 제안(3만원) 발송 후 답장 없음", { "⑤확정": "TRUE", "①DM 발송": "TRUE", "②응답": "FALSE" })).recommendedStatus, "1차 발송");
  assert.equal(classifyRow(row("확정", "협업 수락", { "⑤확정": "TRUE", "배정 건": "미미라인 중국", "⑥방문 예정일": "9/2 18:00" })), null);
  assert.equal(classifyRow(row("확정", "협업 수락", { "⑤확정": "TRUE", "배정 건": "미미라인 중국", "⑥방문 예정일": "아직 미정." })).recommendedStatus, "일정 보류");
  assert.equal(classifyRow(row("확정", "이번 배정 취소", { "⑤확정": "TRUE" })).mode, "review");
  console.log("build-status-audit self-test: ok");
}

if (process.argv[1] && process.argv[1].replaceAll("\\", "/").endsWith("build-status-audit.mjs")) {
  const argv = process.argv.slice(2);
  if (argv.includes("--self-test")) selfTest();
  else {
    const flag = (name, fallback = null) => {
      const index = argv.indexOf(`--${name}`);
      return index >= 0 && argv[index + 1] && !argv[index + 1].startsWith("--") ? argv[index + 1] : fallback;
    };
    const result = await buildStatusAudit({
      sheetId: flag("sheet-id", SHEET_ID),
      tab: flag("tab", TAB),
      gid: flag("gid"),
    });
    const out = flag("out");
    if (out) fs.writeFileSync(out, JSON.stringify(result, null, 1), "utf8");
    console.log(JSON.stringify({ 탭: result.탭, 행: result.행, ...result.요약 }, null, 1));
  }
}
